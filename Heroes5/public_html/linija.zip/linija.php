<?php
   require_once("socket_functions.php" );
   $MerchantID = 118585;
   $price = url_get_contents( "https://www.mokejimai.lt/psms/900/?MerchantID={$MerchantID}&code={$_REQUEST['code']}" );
if ($price == 500) {
mysql_query("UPDATE users SET kred=kred+8 where username='$user[username]'");
echo"<small>Jums prideti 8kreditai</small>";
      } elseif ($price  == 2500) {
mysql_query("UPDATE users SET kred=kred+35 where username='$user[username]'");
echo"<small>Jums prideti 35kreditai</small>";
   } else {
   echo"<small>Neteisingas kodas</small>";}
  echo"<br/>$line<br/><small><a href=\"index.php?id=$id\">$home</a></small>";
?>