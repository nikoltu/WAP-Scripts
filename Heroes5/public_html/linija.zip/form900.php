<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<TITLE> 900 linija </TITLE>
</HEAD>
<BODY>
<script language="JavaScript">
 function m_wallet_check_900() {
 if(document.reg_900.code.value.length < 1) {
 alert('Neara�ytas kodas!');
 return false;
 }
 return true;
 }
 </script>
<form name="reg_900" method="post" action="/get900.php" onSubmit="javascript:return m_wallet_check_900();">
<input type="text" name="code" size="10" maxlength="20" class="input-fields"> <input type="submit" value="Avesti apmokejimo koda"
 class="input-button">
</form>
</BODY>
</HTML>